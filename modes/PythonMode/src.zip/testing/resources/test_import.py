import imported_module

assert imported_module.return_twelve() == 12
print 'OK'
exit()