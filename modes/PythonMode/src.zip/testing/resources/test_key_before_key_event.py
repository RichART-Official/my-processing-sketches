def setup():
    pass

def draw():
    text(key, 100, 100)
    print 'OK'
    exit()
